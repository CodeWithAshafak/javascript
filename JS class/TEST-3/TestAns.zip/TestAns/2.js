// Write a JavaScript program when click on button image change.

function change(){
    let selectimg = document.querySelector("#img");
    selectimg.src = "/image/airplane 3.jpg"

 
}