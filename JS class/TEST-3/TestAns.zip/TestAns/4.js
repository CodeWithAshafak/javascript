// Write a JavaScript program to perform a form validation for password field. Form cannot submit if the password field is at least uppercase, lowercase, number and special character.
