// Write a JavaScript program to perform one example of DOM(document object model) and BOM(Browser object model).
