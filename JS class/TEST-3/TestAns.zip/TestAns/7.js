// Write a JavaScript program a box of size 560*700 When a mouse enters a box it converts into a circle.


function change(){
    let main = document.querySelector(".main");
    main.style="border-radius:50%"
}